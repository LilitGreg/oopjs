// function Circle(radius) {
//     this.radius = radius;
//     this.defaultLocation = {x: 0 , y:0};
//     this.computeOptimumLocation = function(factor){
//         //...
//     }
//     this.draw = function(){
//         this.computeOptimumLocation(1.3);
//         console.log('draw');
//     }
// }

// ///object
// const circle = new Circle(10);
// circle.computeOptimumLocation(1.3);
// circle.draw();

/*

Because we can access computeOptimumLocation from outside if 
we add new parameter for computeOptimumLocation
everywhere we  have used this method  we have to come back  and 
 pass an argument.
 One simple change in the implementation of the object result in number of changes in the
 source code.
 if this method was not accessible from the outside  we would  not have  
 circle.computeOptimumLocation(1.3); line

 Abstraction principle in oop is hide the details and show the essentials

 */

/* Implement abstraction using local variable and closure concept */
 
function Circle(radius) {

    ///let color = 'red'; //local variable with this way we can hide 
    // certain member  from the outside

    this.radius = radius;
    ///this.defaultLocation = {x: 0 , y:0};

    let defaultLocation = {x: 0 , y:0};

    let computeOptimumLocation = function(factor){
        //...
    }
    this.draw = function(){
        ///let x,y;
        computeOptimumLocation(1.3);
        //defaultLocation
        //this.radius;
        console.log('draw');
    }
}

///object
const circle = new Circle(10);

///circle.computeOptimumLocation(1.3);
circle.draw();