//console.log('Hello World');

//object literal is the simpler syntax for define the object

const  circle = {
  redius:1,
  location:{
      x:1,
      y:1
  },
  draw: function(){
      console.log('draw');
  }
};

  circle.draw();


//Factory Function using Literal syntax

function createCircle(radius) {
    return{
        radius,
        draw:function(){
            console.log('draw');
        }
    };
}

const circle1 = createCircle(1);
circle1.draw();


//Constructor Function

function Cirlce(radius){
// console.log('this', this);
  this.radius = radius;
  this.draw = function() {
      console.log('draw');
  }
}

// const Cirlecn = new Function('radius', `
//  this.radius = radius;
//   this.draw = function() {
//       console.log('draw');
//   }
//  `);

// const cirlecn = new Cirlecn(1);

Cirlce.call({}, 1);
Cirlce.apply({}, [1,2,3]);

const author = new Cirlce(1);

