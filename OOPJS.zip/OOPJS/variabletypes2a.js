/*
In Javascript we have 2 categories of types:

-- Value Types(primitives)
-----Number
-----Sting
-----Boolean
-----Symbol
-----undefined
-----null

-- Reference Types 
-----Object
-----Function
-----Array
*/

/// x and y are independent 

let x = 10;
let y = x;

x = 20;

////// x and y influence each other   
/*
  Both x and y are pointed  to the same object of memory.
And when we modified that object using  either x and y, it changes imidetly  visible
to the other variable.
*/


/*
Primitives are copied by their value.
Objects are copied by their reference.
*/

let z = {value:10}
let j = z;

z.value = 20;

////////////
let number = 10;
function increase(number) {
    number ++;
}
increase(number);
console.log(number); //10 


//////////// 
let obj = {value:10};
function increaseob(obj) {
    obj.value ++;
}

increaseob(obj);
console.log(obj); // 11 

/////////////////

function Circle(radius) {
    this.radius = radius;
    this.draw = function(){
        console.log('draw');
    }
}

///object
const circle = new Circle(10);

//use.token = 'addddd';
//add property

circle.location = {x : 1};
///circle['location'] = {x: 1};
//const propertyName = 'center-location';
//circle[propertyName] = {x:1};


//delete property
delete circle.location;
/// delete circle['location];


for (let key in circle) {
    if(typeof circle[key]!= 'function')
    console.log(key, circle[key]);
}

//display keys of object 

const keys = Object.keys(circle);
console.log(keys);

///if exist specific property or methods

if('radius' in circle) {
    console.log('Circle has a radius');
}











