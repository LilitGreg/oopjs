let baseSallary = 30_000;
let overtime = 10;
let rate = 20;

function getWage(baseSallary, overtime,rate) {
    return baseSallary + (overtime* rate);
}

//Encapsulation 
//the best function are those with no parameters

/*
 Using Encapsulation we group related variables and functions
 together  and this way we can  ----reduce complexity.
 And we can reuse this object in different parts of program 
 or in different programs. --- increase reusability
*/

let employee = {
    baseSallary : 30_000,
     overtime : 10,
     rate: 20,
     getWage: function() {
         return this.baseSallary + (this.overtime * this.rate);
     }
};
employee.getWage();

//// Abstraction
//We hide some of the properties and methods from the outside 
// and it give us couple of benefits:
// 1.Simpler interface
// 2.Reduce the impact of Change

/*
We hide details  and  complexity  and show only essentials,This
technique --- reduce complexity and  --- isolate implace of changes in the code.

*/

///Inheritance
// Inheritance helps us eliminate redundant Code

/*
With Inheritance we can eliminate redundant Code
*/

////Poly morphism

// Poly morphism  allows get rid of the long if/else or switch / case statements

/*
 With Poly morphism we can  refactor ugly switch/case statements
*/
//element.render();



