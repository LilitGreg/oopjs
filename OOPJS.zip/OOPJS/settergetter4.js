///////////////////////Version 1 ////////////////
///Access  defaultLocation local variable using method

// function Circle(radius) {

//     this.radius = radius;
//     ///this.defaultLocation = {x: 0 , y:0};

//     let defaultLocation = {x: 0 , y:0};

//     this.getDefaultLocation = function(){
//         return defaultLocation;
//     }

     
//     this.draw = function(){
//         console.log('draw');
//     }
// }

// ///object
// const circle = new Circle(10);

// circle.getDefaultLocation(); //access local defaultLocation variable using method

// circle.draw();


///////////////////////////version 2//////


////Access  defaultLocation local variable using get 

function Circle(radius) {

    this.radius = radius;
    ///this.defaultLocation = {x: 0 , y:0};

    let defaultLocation = {x: 0 , y:0};

    this.getDefaultLocation = function(){
        return defaultLocation;
    }
    this.draw = function(){
        console.log('draw');
    }

    Object.defineProperty(this,'defaultLocation', {
        get: function(){
            return defaultLocation;
        },
        set: function(value) {
           if(!value.x || !value.y)
           throw new Error("Invalid location.");
           defaultLocation = value;
        }
    });
}

///object
const circle = new Circle(10);

circle.getDefaultLocation(); //access local defaultLocation variable using method
circle.defaultLocation; /// get function will be called

////circle.defaultLocation = 1; //Error will display: "Invalid location";

circle.defaultLocation = {x: 4, y: 8}; //set function will be called
circle.defaultLocation;
circle.draw();